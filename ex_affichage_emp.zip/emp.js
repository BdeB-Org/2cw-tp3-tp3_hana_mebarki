function createNode(element) {
  return document.createElement(element);
}

function append(parent, el) {
  return parent.appendChild(el);
}
//Main
const emp_ul = document.getElementById("employees");
const elemH1 = document.getElementById("h1");
const url = "http://127.0.0.1:8080/ords/hr2/employees";
elemH1.innerHTML = "Liste des employees";
fetch(url)
  .then((resp) => resp.json())
  .then(function (data) {
    let employees = data.items; //.results;
    return employees.map(function (employee) {
      let li = createNode("li"),
        span = createNode("span");
      span.innerHTML = `${employee.empno} ${employee.ename} ${employee.job}`;
      append(li, span);
      append(emp_ul, li);
    });
  })
  .catch(function (error) {
    console.log(JSON.stringify(error));
  });
